import { useEffect, useRef } from "react";

// ─── TYPES ───────────────────────────────────────────────────────────────────
interface Service { num: string; name: string; duration: string; price: string; }
interface Review { text: string; author: string; service: string; barber: string; date: string; }
interface TeamMember { initial: string; name: string; reviews: number; tags: string[]; bio: string; }

// ─── CONSTANTS ───────────────────────────────────────────────────────────────
const TREATWELL_URL = "https://www.treatwell.de/ort/maennersache-hamburg-barbershop/";
const PHONE = "+4915560094443";
const PHONE_DISPLAY = "+49 155 6009 4443";
const MAPS_URL = "https://maps.google.com/?q=Dehnhaide+23+22081+Hamburg";

const SERVICES: Service[] = [
  { num: "01", name: "Herren-Haarschnitt", duration: "30 Min.", price: "32 €" },
  { num: "02", name: "Waschen, Schneiden & Föhnen", duration: "30 Min.", price: "38 €" },
  { num: "03", name: "Bart trimmen", duration: "20 Min.", price: "26 €" },
  { num: "04", name: "Traditionelle Kopfrasur", duration: "30 Min.", price: "35 €" },
  { num: "05", name: "Gentleman Paket", duration: "50 Min. · Haarschnitt & Bart", price: "52 €" },
  { num: "06", name: "Business Paket", duration: "1 Std. · Haarschnitt & Rasur", price: "62 €" },
  { num: "07", name: "Königspaket", duration: "1 Std. 15 Min. · Komplett", price: "98 €" },
  { num: "08", name: "Maschinenschnitt", duration: "15 Min.", price: "20 €" },
];

const REVIEWS: Review[] = [
  { text: "Perfekt auf meine Wünsche eingegangen. Hatte lange nicht mehr so gut geschnittene Haare.", author: "Lukas", service: "Herren-Trockenhaarschnitt", barber: "Serkan", date: "vor 19 Stunden" },
  { text: "Klasse Barbershop, sehr gern wieder. Die Atmosphäre ist entspannt und gemütlich. Der Haarschnitt sitzt perfekt. Klare Empfehlung!", author: "Dennis", service: "Augenbrauen, Waxing & Haarschnitt", barber: "Serkan", date: "vor 5 Tagen" },
  { text: "Serkan ist ein herausragender Friseur. Er nimmt sich Zeit, berät ehrlich und setzt jeden Schnitt präzise um. Ein echtes Plus an Selbstbewusstsein.", author: "Cliff", service: "Herrenhaarschnitt", barber: "Serkan", date: "vor 7 Tagen" },
  { text: "Super Haarschnitt, super Bartschnitt und toller Barber Shop. Sehr zu empfehlen!", author: "Oliver", service: "Herren-Trockenhaarschnitt", barber: "Serkan", date: "vor 6 Tagen" },
  { text: "War alles in Ordnung. Sehr freundlich und professionell. Komme gerne wieder.", author: "Janek", service: "Herren-Trockenhaarschnitt", barber: "Levent", date: "vor 22 Stunden" },
  { text: "Der alte Stil des Ladens ist perfekt gewählt und schafft eine super Atmosphäre. Man merkt, dass hier jeder Handgriff sitzt.", author: "Cliff", service: "Gentleman Paket", barber: "Serkan", date: "vor 7 Tagen" },
];

const TEAM: TeamMember[] = [
  { initial: "S", name: "Serkan", reviews: 87, tags: ["Kompetent", "Freundlich", "Außergewöhnlich", "Erfahren"], bio: "Friseur · Haarentfernung · Gesicht. Einer der besten Barber Hamburgs – präzise, herzlich, immer up to date." },
  { initial: "L", name: "Levent", reviews: 57, tags: ["Professionell", "Freundlich"], bio: "Friseur · Haarentfernung · Gesicht. Ruhig, präzise, verlässlich – jeder Schnitt ein Statement." },
];

// ─── DESIGN TOKENS ───────────────────────────────────────────────────────────
const C = {
  black: "#111111",
  mid: "#666666",
  muted: "#aaaaaa",
  border: "#E5E5E5",
  bg: "#F8F8F6",
  white: "#ffffff",
  gold: "#9E7A40",
};
const SERIF = "'Cormorant Garamond', serif";
const SANS = "'DM Sans', sans-serif";

// ─── GLOBAL STYLES ───────────────────────────────────────────────────────────
const GLOBAL_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&display=swap');
  *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
  html { scroll-behavior: smooth; }
  body { font-family: 'DM Sans', sans-serif; background: #fff; color: #111; overflow-x: hidden; }
  a { text-decoration: none; color: inherit; }
  ul { list-style: none; }

  .ms-nav-link {
    font-size: 0.78rem; font-weight: 500; letter-spacing: 0.16em;
    text-transform: uppercase; color: #666; transition: color 0.2s;
  }
  .ms-nav-link:hover { color: #111; }

  .ms-btn-outline {
    display: inline-block; font-size: 0.75rem; font-weight: 500;
    letter-spacing: 0.16em; text-transform: uppercase;
    color: #111; border: 1.5px solid #111; padding: 0.75rem 1.8rem;
    transition: background 0.3s, color 0.3s; cursor: pointer;
  }
  .ms-btn-outline:hover { background: #111; color: #fff; }

  .ms-btn-outline-lg {
    display: inline-block; font-size: 0.78rem; font-weight: 500;
    letter-spacing: 0.16em; text-transform: uppercase;
    color: #111; border: 1.5px solid #111; padding: 1.1rem 2.8rem;
    transition: background 0.3s, color 0.3s; cursor: pointer;
  }
  .ms-btn-outline-lg:hover { background: #111; color: #fff; }

  .ms-btn-inv {
    display: inline-block; font-size: 0.78rem; font-weight: 500;
    letter-spacing: 0.16em; text-transform: uppercase;
    color: #111; background: #fff; border: 1.5px solid #fff; padding: 1.1rem 2.8rem;
    transition: background 0.3s, color 0.3s; cursor: pointer;
  }
  .ms-btn-inv:hover { background: transparent; color: #fff; }

  .ms-text-link {
    font-size: 0.72rem; font-weight: 500; letter-spacing: 0.16em;
    text-transform: uppercase; color: #666;
    display: inline-flex; align-items: center; gap: 0.5rem; transition: color 0.2s;
  }
  .ms-text-link:hover { color: #111; }

  .ms-addr-link {
    font-size: 0.75rem; font-weight: 500; letter-spacing: 0.14em;
    text-transform: uppercase; color: #111;
    display: inline-flex; align-items: center; gap: 0.6rem; transition: gap 0.3s;
  }
  .ms-addr-link:hover { gap: 1.1rem; }

  .ms-service-cell {
    padding: 2.2rem 1.8rem; display: flex; flex-direction: column;
    gap: 0.4rem; background: #fff; position: relative; overflow: hidden;
    transition: background 0.3s; cursor: default;
  }
  .ms-service-cell:hover { background: #F8F8F6; }
  .ms-service-cell .ms-underline {
    position: absolute; bottom: 0; left: 0; right: 0; height: 2px;
    background: #111; transform: scaleX(0); transform-origin: left; transition: transform 0.35s;
  }
  .ms-service-cell:hover .ms-underline { transform: scaleX(1); }

  .ms-phone-sub { font-size: 0.72rem; color: #aaa; display: flex; align-items: center; gap: 0.5rem; transition: color 0.2s; }
  .ms-phone-sub:hover { color: #111; }

  .ms-phone-inv { font-family: 'Cormorant Garamond', serif; font-size: 1.4rem; font-weight: 400; color: rgba(255,255,255,0.4); transition: color 0.3s; }
  .ms-phone-inv:hover { color: #fff; }
`;

// ─── FADE-IN COMPONENT ───────────────────────────────────────────────────────
function FadeIn({
  children,
  delay = 0,
  style = {},
}: {
  children: React.ReactNode;
  delay?: number;
  style?: React.CSSProperties;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.style.opacity = "1";
          el.style.transform = "translateY(0)";
        }
      },
      { threshold: 0.07 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      style={{
        opacity: 0,
        transform: "translateY(24px)",
        transition: `opacity 0.7s ease ${delay}ms, transform 0.7s ease ${delay}ms`,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// ─── STARS ───────────────────────────────────────────────────────────────────
function Stars() {
  return (
    <span style={{ color: C.gold, letterSpacing: "0.1em" }}>★★★★★</span>
  );
}

// ─── SERVICE CELL ─────────────────────────────────────────────────────────────
function ServiceCell({ s, borderRight }: { s: Service; borderRight: boolean }) {
  return (
    <div
      className="ms-service-cell"
      style={{ borderRight: borderRight ? `1px solid ${C.border}` : "none" }}
    >
      <span className="ms-underline" />
      <span style={{ fontSize: "0.65rem", color: C.muted, letterSpacing: "0.2em", marginBottom: "0.4rem" }}>
        {s.num}
      </span>
      <span style={{ fontFamily: SERIF, fontSize: "1.1rem", fontWeight: 600, lineHeight: 1.3 }}>
        {s.name}
      </span>
      <span style={{ fontSize: "0.75rem", color: C.muted }}>{s.duration}</span>
      <span style={{ fontFamily: SERIF, fontSize: "1.5rem", fontWeight: 600, marginTop: "auto", paddingTop: "1rem" }}>
        {s.price}
      </span>
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────
export default function MaennersachePage() {
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: GLOBAL_CSS }} />

      <div style={{ fontFamily: SANS }}>

        {/* ══════════════════════════════════════════
            NAV
        ══════════════════════════════════════════ */}
        <nav style={{
          position: "fixed", top: 0, left: 0, right: 0, zIndex: 200,
          background: "rgba(255,255,255,0.97)", borderBottom: `1px solid ${C.border}`,
          backdropFilter: "blur(10px)",
        }}>
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "2rem 4rem", gap: "3rem",
          }}>
            <a href="#" style={{ fontFamily: SERIF, fontSize: "1.45rem", fontWeight: 600, letterSpacing: "0.04em", color: C.black }}>
              Männersache
            </a>

            <ul style={{ display: "flex", alignItems: "center", gap: "3rem", flex: 1, justifyContent: "center" }}>
              {[["#leistungen", "Leistungen"], ["#bewertungen", "Bewertungen"], ["#team", "Team"], ["#kontakt", "Kontakt"]].map(([href, label]) => (
                <li key={label}>
                  <a href={href} className="ms-nav-link">{label}</a>
                </li>
              ))}
            </ul>

            <a href={TREATWELL_URL} target="_blank" rel="noopener noreferrer" className="ms-btn-outline">
              Termin buchen
            </a>
          </div>
        </nav>

        {/* ══════════════════════════════════════════
            HERO
        ══════════════════════════════════════════ */}
        <section style={{
          minHeight: "100vh", display: "flex", flexDirection: "column",
          justifyContent: "flex-end", padding: "0 4rem 5rem",
          background: C.white, position: "relative", overflow: "hidden",
          paddingTop: "8rem",
        }}>
          {/* Eyebrow */}
          <FadeIn style={{ position: "absolute", top: "9rem", left: "4rem" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "1rem", fontSize: "0.72rem", fontWeight: 500, letterSpacing: "0.28em", textTransform: "uppercase", color: C.muted }}>
              <span style={{ width: 28, height: 1, background: C.muted, display: "block" }} />
              Barbershop · Hamburg Barmbek
            </div>
          </FadeIn>

          {/* Rating pill */}
          <FadeIn delay={100} style={{ position: "absolute", top: "9rem", right: "4rem" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.8rem", border: `1px solid ${C.border}`, padding: "0.6rem 1.2rem" }}>
              <Stars />
              <span style={{ fontSize: "0.72rem", color: C.mid }}>5,0 · 185 Bewertungen</span>
              <span style={{ fontSize: "0.68rem", color: C.muted }}>via Treatwell</span>
            </div>
          </FadeIn>

          {/* Scroll hint */}
          <div style={{ position: "absolute", right: "4rem", top: "50%", transform: "translateY(-50%)", display: "flex", flexDirection: "column", alignItems: "center", gap: "0.8rem" }}>
            <span style={{ fontSize: "0.63rem", letterSpacing: "0.3em", textTransform: "uppercase", color: C.muted, writingMode: "vertical-rl" }}>
              Scroll
            </span>
            <span style={{ width: 1, height: 60, background: C.border, display: "block" }} />
          </div>

          {/* H1 */}
          <FadeIn delay={100}>
            <h1 style={{
              fontFamily: SERIF,
              fontSize: "clamp(5rem, 11vw, 9.5rem)",
              fontWeight: 300, lineHeight: 0.88,
              letterSpacing: "-0.02em", color: C.black,
              marginBottom: "3.5rem",
            }}>
              Männer-<br />
              <em style={{ fontStyle: "italic" }}>sache.</em>
            </h1>
          </FadeIn>

          {/* Bottom row */}
          <FadeIn delay={200}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: "2rem" }}>
              <p style={{ fontSize: "0.95rem", fontWeight: 300, color: C.mid, lineHeight: 1.85, maxWidth: 400 }}>
                Präzise Herrenhaarschnitte, saubere Bartlinien und echter Männerstil.<br />
                <strong style={{ fontWeight: 500, color: C.black }}>Dehnhaide 23, Hamburg Barmbek</strong> — Mo–Sa geöffnet.
              </p>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "0.9rem" }}>
                <a href={TREATWELL_URL} target="_blank" rel="noopener noreferrer" className="ms-btn-outline-lg">
                  Termin buchen
                </a>
                <a href={`tel:${PHONE}`} className="ms-phone-sub">
                  <span style={{ fontSize: "0.9rem" }}>↗</span> {PHONE_DISPLAY}
                </a>
              </div>
            </div>
          </FadeIn>
        </section>

        {/* ══════════════════════════════════════════
            INFO STRIP
        ══════════════════════════════════════════ */}
        <FadeIn>
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "1.5rem 4rem", borderTop: `1px solid ${C.border}`,
            borderBottom: `1px solid ${C.border}`, background: C.bg,
          }}>
            {["Dehnhaide 23 · 22081 Hamburg", "Mo – Fr  10:00 – 19:30", "Sa  09:00 – 19:30", "Serkan & Levent", "✂ Premium Barbershop"].map(item => (
              <div key={item} style={{ display: "flex", alignItems: "center", gap: "0.6rem", fontSize: "0.72rem", fontWeight: 500, letterSpacing: "0.2em", textTransform: "uppercase", color: C.mid }}>
                <span style={{ width: 4, height: 4, borderRadius: "50%", background: C.muted, flexShrink: 0 }} />
                {item}
              </div>
            ))}
          </div>
        </FadeIn>

        {/* ══════════════════════════════════════════
            SERVICES
        ══════════════════════════════════════════ */}
        <section id="leistungen" style={{ padding: "8rem 4rem", background: C.white, borderBottom: `1px solid ${C.border}` }}>
          <FadeIn>
            <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: "4rem" }}>
              <div>
                <div style={{ fontSize: "0.7rem", fontWeight: 500, letterSpacing: "0.28em", textTransform: "uppercase", color: C.muted, marginBottom: "0.8rem" }}>
                  Unsere Leistungen
                </div>
                <h2 style={{ fontFamily: SERIF, fontSize: "clamp(2.2rem, 4.5vw, 3.5rem)", fontWeight: 400, lineHeight: 1.08 }}>
                  Was wir für dich<br /><em style={{ fontStyle: "italic" }}>tun können.</em>
                </h2>
              </div>
              <a href={TREATWELL_URL} target="_blank" rel="noopener noreferrer" className="ms-text-link">
                Alle Services buchen <span style={{ fontSize: "1rem" }}>↗</span>
              </a>
            </div>
          </FadeIn>

          <FadeIn delay={100}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", border: `1px solid ${C.border}` }}>
              {SERVICES.slice(0, 4).map((s, i) => (
                <ServiceCell key={s.num} s={s} borderRight={i < 3} />
              ))}
            </div>
          </FadeIn>

          <FadeIn delay={200}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", border: `1px solid ${C.border}`, borderTop: "none" }}>
              {SERVICES.slice(4).map((s, i) => (
                <ServiceCell key={s.num} s={s} borderRight={i < 3} />
              ))}
            </div>
          </FadeIn>
        </section>

        {/* ══════════════════════════════════════════
            REVIEWS
        ══════════════════════════════════════════ */}
        <section id="bewertungen" style={{ padding: "8rem 4rem", background: C.bg }}>
          <FadeIn>
            <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: "4rem" }}>
              <div>
                <div style={{ fontSize: "0.7rem", fontWeight: 500, letterSpacing: "0.28em", textTransform: "uppercase", color: C.muted, marginBottom: "0.8rem" }}>
                  Kundenbewertungen
                </div>
                <div style={{ display: "flex", alignItems: "baseline", gap: "1.2rem" }}>
                  <span style={{ fontFamily: SERIF, fontSize: "5.5rem", fontWeight: 300, lineHeight: 1, color: C.black }}>5,0</span>
                  <div style={{ display: "flex", flexDirection: "column", gap: "0.4rem", paddingBottom: "0.5rem" }}>
                    <Stars />
                    <span style={{ fontSize: "0.72rem", color: C.mid }}>185 verifizierte Bewertungen</span>
                  </div>
                </div>
              </div>
              <a href={`${TREATWELL_URL}bewertungen/`} target="_blank" rel="noopener noreferrer" className="ms-text-link">
                Alle Bewertungen <span style={{ fontSize: "1rem" }}>↗</span>
              </a>
            </div>
          </FadeIn>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1px", background: C.border }}>
            {REVIEWS.map((r, i) => (
              <FadeIn key={i} delay={i * 80}>
                <div style={{ background: C.white, padding: "2.5rem 2rem", display: "flex", flexDirection: "column", gap: "1.2rem", height: "100%" }}>
                  <Stars />
                  <p style={{ fontFamily: SERIF, fontSize: "1.05rem", fontStyle: "italic", lineHeight: 1.75, color: C.black, flex: 1 }}>
                    "{r.text}"
                  </p>
                  <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: "1rem", display: "flex", flexDirection: "column", gap: "0.25rem" }}>
                    <span style={{ fontSize: "0.8rem", fontWeight: 500, color: C.black }}>{r.author}</span>
                    <span style={{ fontSize: "0.7rem", color: C.muted }}>{r.service} · bei {r.barber}</span>
                    <span style={{ fontSize: "0.68rem", color: C.muted }}>{r.date}</span>
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>

          <FadeIn delay={200}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.8rem", marginTop: "3rem", fontSize: "0.72rem", letterSpacing: "0.1em", textTransform: "uppercase", color: C.muted }}>
              <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 20, height: 20, borderRadius: "50%", background: C.black, color: "#fff", fontSize: "0.65rem", flexShrink: 0 }}>
                ✓
              </span>
              Verifizierte Bewertungen via Treatwell
            </div>
          </FadeIn>
        </section>

        {/* ══════════════════════════════════════════
            TEAM
        ══════════════════════════════════════════ */}
        <section id="team" style={{ padding: "8rem 4rem", background: C.white, borderTop: `1px solid ${C.border}` }}>
          <FadeIn>
            <div style={{ fontSize: "0.7rem", fontWeight: 500, letterSpacing: "0.28em", textTransform: "uppercase", color: C.muted, marginBottom: "0.8rem" }}>
              Das Team
            </div>
            <h2 style={{ fontFamily: SERIF, fontSize: "clamp(2.2rem, 4.5vw, 3.5rem)", fontWeight: 400, lineHeight: 1.08, marginBottom: "4rem" }}>
              Deine <em style={{ fontStyle: "italic" }}>Barber.</em>
            </h2>
          </FadeIn>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1px", background: C.border }}>
            {TEAM.map((m, i) => (
              <FadeIn key={m.name} delay={i * 100}>
                <div style={{ background: C.white, padding: "3rem 2.5rem", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
                  <span style={{ fontFamily: SERIF, fontSize: "5rem", fontWeight: 300, color: C.border, lineHeight: 1 }}>
                    {m.initial}
                  </span>
                  <div>
                    <div style={{ fontFamily: SERIF, fontSize: "2rem", fontWeight: 600, marginBottom: "0.5rem" }}>{m.name}</div>
                    <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", fontSize: "0.8rem", color: C.mid }}>
                      <Stars /> 5,0 · {m.reviews} Bewertungen
                    </div>
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem" }}>
                    {m.tags.map(tag => (
                      <span key={tag} style={{ fontSize: "0.7rem", fontWeight: 500, letterSpacing: "0.1em", textTransform: "uppercase", border: `1px solid ${C.border}`, padding: "0.4rem 0.9rem", color: C.mid }}>
                        {tag}
                      </span>
                    ))}
                  </div>
                  <p style={{ fontSize: "0.85rem", color: C.mid, lineHeight: 1.75, fontWeight: 300 }}>{m.bio}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </section>

        {/* ══════════════════════════════════════════
            INFO / KONTAKT
        ══════════════════════════════════════════ */}
        <section id="kontakt" style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "1px", background: C.border, borderTop: `1px solid ${C.border}` }}>
          {/* Öffnungszeiten */}
          <FadeIn style={{ background: C.bg, padding: "3rem 2.5rem", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
            <div style={{ fontSize: "0.7rem", fontWeight: 500, letterSpacing: "0.28em", textTransform: "uppercase", color: C.muted }}>
              Öffnungszeiten
            </div>
            <div>
              {[["Mo – Fr", "10:00 – 19:30"], ["Samstag", "09:00 – 19:30"], ["Sonntag", "Geschlossen"]].map(([day, time]) => (
                <div key={day} style={{ display: "flex", justifyContent: "space-between", padding: "0.75rem 0", borderBottom: `1px solid ${C.border}`, fontSize: "0.85rem" }}>
                  <span style={{ color: C.mid }}>{day}</span>
                  <span style={{ fontWeight: time === "Geschlossen" ? 300 : 500, color: time === "Geschlossen" ? C.muted : C.black }}>
                    {time}
                  </span>
                </div>
              ))}
            </div>
          </FadeIn>

          {/* Standort */}
          <FadeIn delay={100} style={{ background: C.bg, padding: "3rem 2.5rem", display: "flex", flexDirection: "column", gap: "1.2rem" }}>
            <div style={{ fontSize: "0.7rem", fontWeight: 500, letterSpacing: "0.28em", textTransform: "uppercase", color: C.muted }}>
              Standort
            </div>
            <h3 style={{ fontFamily: SERIF, fontSize: "1.6rem", fontWeight: 600, lineHeight: 1.2 }}>
              Barmbek-Süd,<br />Hamburg
            </h3>
            <p style={{ fontSize: "0.9rem", color: C.mid, lineHeight: 1.8 }}>
              Dehnhaide 23<br />22081 Hamburg
            </p>
            <a href={MAPS_URL} target="_blank" rel="noopener noreferrer" className="ms-addr-link" style={{ marginTop: "auto" }}>
              In Google Maps öffnen <span>→</span>
            </a>
          </FadeIn>

          {/* Buchung */}
          <FadeIn delay={200} style={{ background: C.bg, padding: "3rem 2.5rem", display: "flex", flexDirection: "column", gap: "1.2rem" }}>
            <div style={{ fontSize: "0.7rem", fontWeight: 500, letterSpacing: "0.28em", textTransform: "uppercase", color: C.muted }}>
              Kontakt & Buchung
            </div>
            <h3 style={{ fontFamily: SERIF, fontSize: "1.6rem", fontWeight: 600, lineHeight: 1.2 }}>
              Direkt<br />buchen.
            </h3>
            <p style={{ fontSize: "0.9rem", color: C.mid, lineHeight: 1.8 }}>
              Online via Treatwell oder direkt anrufen – wir sind für dich da.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: "0.8rem", marginTop: "auto" }}>
              <a href={TREATWELL_URL} target="_blank" rel="noopener noreferrer" className="ms-addr-link">
                Auf Treatwell buchen <span>→</span>
              </a>
              <a href={`tel:${PHONE}`} className="ms-addr-link">
                {PHONE_DISPLAY} <span>→</span>
              </a>
            </div>
          </FadeIn>
        </section>

        {/* ══════════════════════════════════════════
            CTA BLOCK
        ══════════════════════════════════════════ */}
        <section style={{
          padding: "6rem 4rem", background: C.black,
          display: "flex", alignItems: "center", justifyContent: "space-between", gap: "3rem",
        }}>
          <FadeIn>
            <h2 style={{ fontFamily: SERIF, fontSize: "clamp(2rem, 4vw, 3.2rem)", fontWeight: 300, color: "#fff", lineHeight: 1.1, marginBottom: "0.5rem" }}>
              Bereit für den<br /><em style={{ fontStyle: "italic" }}>perfekten Schnitt?</em>
            </h2>
            <p style={{ fontSize: "0.9rem", color: "rgba(255,255,255,0.4)", fontWeight: 300 }}>
              Buche deinen Termin direkt online – schnell, einfach, ohne Wartezeit.
            </p>
          </FadeIn>
          <FadeIn delay={100}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "0.9rem", flexShrink: 0 }}>
              <a href={TREATWELL_URL} target="_blank" rel="noopener noreferrer" className="ms-btn-inv">
                Jetzt auf Treatwell buchen
              </a>
              <a href={`tel:${PHONE}`} className="ms-phone-inv">
                {PHONE_DISPLAY}
              </a>
            </div>
          </FadeIn>
        </section>

        {/* ══════════════════════════════════════════
            FOOTER
        ══════════════════════════════════════════ */}
        <footer style={{
          padding: "2rem 4rem", background: C.black,
          borderTop: "1px solid #2a2a2a",
          display: "flex", alignItems: "center", justifyContent: "space-between",
        }}>
          <span style={{ fontFamily: SERIF, fontSize: "1.1rem", fontWeight: 600, color: "rgba(255,255,255,0.35)" }}>
            Männersache Barbershop
          </span>
          <span style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.2)", letterSpacing: "0.08em" }}>
            © 2025 · Dehnhaide 23 · 22081 Hamburg
          </span>
        </footer>

      </div>
    </>
  );
}
